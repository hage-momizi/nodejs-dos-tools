function startAttack() {
    const url = document.getElementById('url').value;
    const threads = document.getElementById('threads').value;
    const requestsPerThread = document.getElementById('requestsPerThread').value;

    fetch('/start-attack', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
        },
        body: JSON.stringify({
            url,
            threads,
            requestsPerThread,
        }),
    })
    .then(response => response.text())
    .then(data => alert(data))
    .catch(error => alert(`エラーが発生しました: ${error.message}`));
}

function stopAttack() {
    fetch('/stop-attack', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
        },
    })
    .then(response => response.text())
    .then(data => alert(data))
    .catch(error => alert(`エラーが発生しました: ${error.message}`));
}
